__version__ = "0.2.2"

from ._core import icon_svg, metadata

__all__ = (
    "icon_svg",
    "metadata",
)
